/**
 * New node file
 */

app.controller("yearCtrl", function($scope, $http) {
	var source = './json/Years.json';
	$scope.years = [];
	$scope.selected = 'Year';

	$scope.years = [ "2010-1431", "2009-1430", "2008-1429", "2007-1428",
			"2006-1427" ];

	$http.get(source).success(function(response) {
		$scope.years = response;
		if ($scope.years.length > 0)
			$scope.selected = $scope.years[0];
		else
			$scope.selected = 'Year';
	});

	$scope.setSelected = function(year) {
		console.log(year);
		$scope.selected = year;
	}

});
