/**
 * New node file
 */
var app = angular.module("myApp", []);