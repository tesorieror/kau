/**
 * New node file
 */


app.directive('yearDropdown', function() {
	return {
		restrict : 'E',
		templateUrl : './controller/year-dropdown.html',
		scope : {
			info : '='
		},
		controller : 'yearCtrl'
	}
});

app.controller("yearCtrl", function($scope, $http, $element, $attrs) {
	//var source = './json/Years.json';
	console.log($attrs.info);
	var source = $attrs.info;
	$scope.years = [];
	$scope.selected = 'Year';

	// $scope.years = [ "2010-1431", "2009-1430", "2008-1429", "2007-1428",
	// "2006-1427" ];

	$http.get(source).success(function(response) {
		$scope.years = response;
		if ($scope.years.length > 0)
			$scope.selected = $scope.years[0];
		else
			$scope.selected = 'Year';
	});

	$scope.setSelected = function(year) {
		console.log(year);
		$scope.selected = year;
	}
});




// app.controller('Controller', [ '$scope', function($scope) {
// $scope.naomi = {
// name : 'Naomi',
// address : '1600 Amphitheatre'
// };
// $scope.igor = {
// name : 'Igor',
// address : '123 Somewhere'
// };
// } ]).directive('myCustomer', function() {
// return {
// restrict : 'E',
// scope : {
// customerInfo : '=info'
// },
// templateUrl : './controller/my-customer-iso.html'
// };
// });
