/**
 * New node file
 */

app.directive('pie-chart', function() {
	return {
		restrict : 'E',
		templateUrl : './controller/pie-chart.html',
		scope : {
			source: '='
		},
		controller : 'pieChartCtrl'
	}
});

app.controller("pieChartCtrl", function($scope, $http, $element, $attrs) {

	
	
});