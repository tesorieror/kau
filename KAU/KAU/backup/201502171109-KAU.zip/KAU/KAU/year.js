/**
 * New node file
 */

function DropdownController(id, source) {

	this.id = id; // #yearSelector2
	this.source = source; // './json/Years.json'

	this.select = function(item) {
		console.log('Selected year: ' + item.text());
		$('ul#' + this.id + ' li.dropdown a.dropdown-toggle').html(
				item.text() + ' <span class="caret"></span>');
		$('ul#' + this.id + ' li.dropdown ul.dropdown-menu li').removeClass(
				'active');
		item.parent().addClass('active');
	}

	var self = this;

	$.getJSON(
			this.source,
			function(data) {
				console.log('Years successfully loaded');
				console.log(data);
				var dropdown = $('ul#' + self.id + ' li.dropdown ul.dropdown-menu');
				dropdown.empty();

				var first = null;
				$.each(data, function(i, value) {
					var a = $('<a>');
					a.html(value);
					a.attr('href', '#');
					var li = $('<li>');
					li.append(a);
					dropdown.append(li);
					if (first == null) {
						first = a;
					}
				});

				$('ul#' + this.id + ' li.dropdown a.dropdown-toggle').html(
						'Year <span class="caret"></span>');

				$('ul#' + this.id + ' li.dropdown ul.dropdown-menu li a').click(
						function() {
							self.select($(this));
						});

				self.select(first);

			}).fail(function(jqxhr, textStatus, error) {
		console.err(textStatus);
		console.err(error);
	});
};

