/**
 * Freshmen Bar chart
 */

google.load("visualization", "1", {
	packages : [ "corechart" ]
});
google.setOnLoadCallback(drawBarChart);

function drawBarChart() {
	var data = google.visualization.arrayToDataTable([
			[ 'Genere', 'Male', 'Female', {
				role : 'annotation'
			} ], [ 'Students', 164787, 132845, 297632 ],
			[ 'Saudi', 159558, 130147, 289705 ],
			[ 'Non-Saudi', 5229, 2698, 297632 ],
			[ 'Bachelore', 114222, 113503, 227725 ],
			[ 'Diploma', 13795, 42556, 56351 ] ]);

	var view = new google.visualization.DataView(data);

	var options = {
		title : "Freshmen data",
		width : 600,
		height : 400,
		bar : {
			groupWidth : "95%"
		},
		legend : {
			position : "bottom"
		},
		isStacked : true,
	};
	var chart = new google.visualization.ColumnChart(document
			.getElementById("freshmenBar"));
	chart.draw(view, options);
}