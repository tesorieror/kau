/**
 * Charts.js
 */

function FreshmenCharts() {

	this.ids = [];
	this.options = [];
	this.data = [];
	this.chart = [];

	// genderPie
	this.ids[0] = 'genderPie';
	this.options['genderPie'] = this.createOptionsForTitle('Student Gender');
	this.data['genderPie'] = [ [ 'Gender', 'Students' ], [ 'Male', 164787 ],
			[ 'Female', 132845 ] ];

	// nationalityPie
	this.ids[1] = 'nationalityPie';
	this.options['nationalityPie'] = this
			.createOptionsForTitle('Student Nationality');
	this.data['nationalityPie'] = [ [ 'Nationality', 'Students' ],
			[ 'Saudi', 289705 ], [ 'Non-Saudi', 297632 ] ];

	// degreePie
	this.ids[2] = 'degreePie';
	this.options['degreePie'] = this.createOptionsForTitle('Student degree');
	this.data['degreePie'] = [ [ 'Degree', 'Students' ],
			[ 'Bachelore', 227725 ], [ 'Diploma', 297632 ] ];

	// saudiGenderPie
	this.ids[3] = 'saudiGenderPie';
	this.options['saudiGenderPie'] = this
			.createOptionsForTitle('Saudi student gender');
	this.data['saudiGenderPie'] = [ [ 'Saudi student gender', 'Students' ],
			[ 'Male', 159558 ], [ 'Female', 130147 ] ];

	// nonSaudiGenderPie
	this.ids[4] = 'nonSaudiGenderPie';
	this.options['nonSaudiGenderPie'] = this
			.createOptionsForTitle('Non-Saudi student gender');
	this.data['nonSaudiGenderPie'] = [
			[ 'Non-Saudi student gender', 'Students' ], [ 'Male', 5229 ],
			[ 'Female', 2698 ] ];

	// bacheloreGenderPie
	this.ids[5] = 'bacheloreGenderPie';
	this.options['bacheloreGenderPie'] = this
			.createOptionsForTitle('Bachelore student gender');
	this.data['bacheloreGenderPie'] = [
			[ 'Bachelore student gender', 'Students' ], [ 'Male', 114222 ],
			[ 'Female', 113503 ] ];

	// diplomaGenderPie
	this.ids[6] = 'diplomaGenderPie';
	this.options['diplomaGenderPie'] = this
			.createOptionsForTitle('Diploma student gender');
	this.data['diplomaGenderPie'] = [ [ 'Diploma student gender', 'Students' ],
			[ 'Male', 13795 ], [ 'Female', 42556 ] ];

	this.createCharts();

	/**
	 * Draw Charts
	 */

	google.setOnLoadCallback(this.drawCharts);
}

FreshmenCharts.prototype.createOptionsForTitle = function(defaultTitle) {
	return {
		title : defaultTitle,
		backgroundColor : {
			fill : 'transparent'
		},
		legend : {
			position : 'bottom'
		},
		width : 200,
		height : 200,
		is3D : true,
		titlePosition : 'top',
		titleTextStyle : {
			fontSize : 12
		},
	};
}

FreshmenCharts.prototype.createCharts = function() {
	for (id in this.ids) {
		this.chart[id] = this.createChart(id);
	}
}

FreshmenCharts.prototype.createChart = function(id) {
	// console.log(google.visualization);
	var data = google.visualization.arrayToDataTable(this.data[id]);
	var chart = new google.visualization.PieChart(document.getElementById(id));
	google.visualization.events.addListener(chart, 'click', function(e) {
		if (e.targetID === "title") {
			console.log(e);
			$('#' + id + 'Modal').modal('show');
		}
	});
	return chart;
}

FreshmenCharts.prototype.drawCharts = function() {
	for (id in this.ids) {
		chart.drawChart(id);
	}
}
FreshmenCharts.prototype.drawChart = function(id) {
	var chart = new google.visualization.PieChart(document.getElementById(id));
	chart.draw(data, options);
}

new FreshmenCharts();

/*
 * google.load("visualization", "1", { packages : [ "corechart" ] });
 * 
 * google.setOnLoadCallback(drawBarChart);
 * 
 * function drawBarChart() { var data = google.visualization.arrayToDataTable([ [
 * 'Genere', 'Male', 'Female', { role : 'annotation' } ], [ 'Students', 164787,
 * 132845, 297632 ], [ 'Saudi', 159558, 130147, 289705 ], [ 'Non-Saudi', 5229,
 * 2698, 297632 ], [ 'Bachelore', 114222, 113503, 227725 ], [ 'Diploma', 13795,
 * 42556, 56351 ] ]);
 * 
 * var view = new google.visualization.DataView(data);
 * 
 * var options = { title : "Freshmen data", width : 600, height : 400, bar : {
 * groupWidth : "95%" }, legend : { position : "bottom" }, isStacked : true,
 * titlePosition : 'none', }; var chart = new
 * google.visualization.ColumnChart(document .getElementById("freshmenBar"));
 * chart.draw(view, options); }
 */

