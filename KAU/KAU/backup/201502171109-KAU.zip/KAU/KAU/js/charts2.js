/**
 * New node file
 */

//function Indicators() {
//
//	var self = this;
//	// var document = this.document;
//
//	// Categories
//	$.getJSON('./json/Categories.json', function(data) {
//		self.categories = data;
//	}).fail(function(jqxhr, textStatus, error) {
//		console.log('Error: ' + textStatus);
//		console.log(error);
//	});
//
//	// Years
//	$.getJSON('./json/Years.json', function(data) {
//		self.years = data;
//		// var items = '<li role="presentation" class="active"><a
//		// href="#">Home</a></li><li role="presentation"><a
//		// href="#">Profile</a></li><li role="presentation"><a
//		// href="#">Messages</a></li>';
//		// var li = document.createElement('li');
//		// $('#yearSelector').append(li);
//		
//		var yearSelector = $('#yearSelector');
//		
//		$.each(data, function(i, value) {
//			console.log(value);			
//			yearSelector.append('<li role="presentation" class="active success"><a href="#">'+value+'</a></li>');
//		});
//
//		// <li role="presentation" class="active">
//		// <a href="#">Home</a>
//		// </li>
//		// <li role="presentation">
//		// <a href="#">Profile</a>
//		// </li>
//		// <li role="presentation">
//		// <a href="#">Messages</a>
//		// </li>
//
//	}).fail(function(jqxhr, textStatus, error) {
//		console.log('Error: ' + textStatus);
//		console.log(error);
//	});
//};
//
//$('document').ready(function() {
//	Indicators();
//});

function PieChartModel(document) {
	this.document = document;

	this.path = './json/';
	this.category = 'students';
	this.year = '2010-1431';
	this.subCategory = 'Freshmen';

	this.jsonFile = 'Students_2010-1431_Freshmen.json';

	// Initialization
	this.initialize();
	this.draw();

};

// PieChartModel.prototype.setCategory(category)
// {
// this.category = category;
// }
// PieChartModel.prototype.setCategory(subCategory)
// {
// this.subCategory = subCategory;
// }
// PieChartModel.prototype.setCategory(year)
// {
// this.year = year;
// draw();
// }

PieChartModel.prototype.initialize = function() {

};

PieChartModel.prototype.getJsonFile = function() {
	return this.path + this.category + '_' + this.year + '_' + this.subCategory
			+ '.json';
};

PieChartModel.prototype.draw = function() {
	console.log('PieChartDraw::draw()');
	console.log(this.getJsonFile());
	var self = this;

	$.getJSON(this.getJsonFile(), function(data) {
		console.log('JSON file loaded');
		console.log(data);
		console.log(self);
		var self2 = self;
		console.log(self2);
		google.setOnLoadCallback(function() {
			console.log(self2);
			self2.drawChart(self2.createChartData(data), self2.document);
		});

	}).fail(function(jqxhr, textStatus, error) {
		console.log('Error: ' + textStatus);
		console.log(error);
	});
};

PieChartModel.prototype.defaultOptions = function() {
	return {
		backgroundColor : {
			fill : 'transparent'
		},
		legend : {
			position : 'bottom'
		},
		width : 200,
		height : 200,
		is3D : true,
		titlePosition : 'top',
		titleTextStyle : {
			fontSize : 12
		},
	};
};

PieChartModel.prototype.merge = function(obj1, obj2) {
	for (key in obj1) {
		obj2[key] = obj1[key];
	}
	return obj2;
};

PieChartModel.prototype.drawChart = function(chartData, document) {
	for (id in chartData) {
		var chart = new google.visualization.PieChart(document
				.getElementById(id));
		chart.draw(google.visualization.arrayToDataTable(chartData[id].data),
				chartData[id].options);
	}
}

PieChartModel.prototype.createChartData = function(model) {
	return {
		'genderPie' : {
			data : [
					[ 'Gender', 'Students' ],
					[ 'Male',
							model['Students']['2010-1431']['Freshmen']['Male'] ],
					[
							'Female',
							model['Students']['2010-1431']['Freshmen']['Female'] ] ],

			options : this.merge(this.defaultOptions(), {
				title : 'Student gender'
			})
		},
		'nationalityPie' : {
			data : [
					[ 'Nationality', 'Students' ],
					[
							'Saudi',
							model['Students']['2010-1431']['Freshmen']['Saudi']['Total'] ],
					[
							'Non-Saudi',
							model['Students']['2010-1431']['Freshmen']['Non-Saudi']['Total'] ] ],
			options : this.merge(this.defaultOptions(), {
				slices : {
					0 : {
						color : 'green'
					},
					1 : {
						color : 'darkGreen'
					}
				},
				title : 'Student nationality'
			})
		},
		'degreePie' : {
			data : [
					[ 'Degree', 'Students' ],
					[
							'Bachelore',
							model['Students']['2010-1431']['Freshmen']['Bachelore']['Total'] ],
					[
							'Diploma',
							model['Students']['2010-1431']['Freshmen']['Diploma']['Total'] ] ],
			options : this.merge(this.defaultOptions(), {
				slices : {
					0 : {
						color : 'brown'
					},
					1 : {
						color : 'DarkGoldenRod'
					}
				},
				title : 'Student degree'
			})
		},
		'saudiGenderPie' : {
			data : [
					[ 'Saudi student gender', 'Students' ],
					[
							'Male',
							model['Students']['2010-1431']['Freshmen']['Saudi']['Male'] ],
					[
							'Female',
							model['Students']['2010-1431']['Freshmen']['Saudi']['Female'] ] ],
			options : this.merge(this.defaultOptions(), {
				title : 'Saudi student gender'
			})
		},
		'nonSaudiGenderPie' : {
			data : [
					[ 'Non-Saudi student gender', 'Students' ],
					[
							'Male',
							model['Students']['2010-1431']['Freshmen']['Non-Saudi']['Male'] ],
					[
							'Female',
							model['Students']['2010-1431']['Freshmen']['Non-Saudi']['Female'] ] ],
			options : this.merge(this.defaultOptions(), {
				title : 'Non-Saudi student gender'
			})
		},
		'bacheloreGenderPie' : {
			data : [
					[ 'Bachelore student gender', 'Students' ],
					[
							'Male',
							model['Students']['2010-1431']['Freshmen']['Bachelore']['Male'] ],
					[
							'Female',
							model['Students']['2010-1431']['Freshmen']['Bachelore']['Female'] ] ],
			options : this.merge(this.defaultOptions(), {
				title : 'Bachelore student gender'
			})
		},
		'diplomaGenderPie' : {
			data : [
					[ 'Diploma student gender', 'Students' ],
					[
							'Male',
							model['Students']['2010-1431']['Freshmen']['Diploma']['Male'] ],
					[
							'Female',
							model['Students']['2010-1431']['Freshmen']['Diploma']['Female'] ] ],
			options : this.merge(this.defaultOptions(), {
				title : 'Diploma student gender'
			})
		},
	};

};

google.load("visualization", "1", {
	packages : [ "corechart" ]
});

new PieChartModel(document);

/*
 * google.load("visualization", "1", { packages : [ "corechart" ] });
 * google.setOnLoadCallback(drawBarChart);
 * 
 * function drawBarChart() { var data = google.visualization.arrayToDataTable([ [
 * 'Genere', 'Male', 'Female', { role : 'annotation' } ], [ 'Students', 164787,
 * 132845, 297632 ], [ 'Saudi', 159558, 130147, 289705 ], [ 'Non-Saudi', 5229,
 * 2698, 297632 ], [ 'Bachelore', 114222, 113503, 227725 ], [ 'Diploma', 13795,
 * 42556, 56351 ] ]);
 * 
 * var view = new google.visualization.DataView(data);
 * 
 * var options = { title : "Freshmen data", width : 600, height : 400, bar : {
 * groupWidth : "95%" }, legend : { position : "bottom" }, isStacked : true,
 * titlePosition : 'none', }; var chart = new
 * google.visualization.ColumnChart(document .getElementById("freshmenBar"));
 * chart.draw(view, options); }
 */