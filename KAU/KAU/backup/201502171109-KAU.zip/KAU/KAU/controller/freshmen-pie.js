app.directive('freshmenPie', function() {
	return {
		restrict : 'E',
		templateUrl : './controller/freshmen-pie.html',
		
		scope : {
			year : '=',
			aspect : '='
		},		
	}
});

app
		.controller(
				"freshmenPieCtrl",
				function($scope, $http, $element, $attrs) {

					this.defaultOptions = function() {
						return {
							backgroundColor : {
								fill : 'transparent'
							},
							legend : {
								position : 'bottom'
							},
							width : 200,
							height : 200,
							is3D : true,
							titlePosition : 'top',
							titleTextStyle : {
								fontSize : 12
							},
						};
					};

					this.merge = function(obj1, obj2) {
						for (key in obj1) {
							obj2[key] = obj1[key];
						}
						return obj2;
					};

					this.createChartData = function(model) {
						return {
							'genderPie' : {
								data : [
										[ 'Gender', 'Students' ],
										[ 'Male',
												model['Students']['2010-1431']['Freshmen']['Male'] ],
										[ 'Female',
												model['Students']['2010-1431']['Freshmen']['Female'] ] ],
								options : this.merge(this.defaultOptions(), {
									title : 'Student gender'
								})
							},
							'nationalityPie' : {
								data : [
										[ 'Nationality', 'Students' ],
										[
												'Saudi',
												model['Students']['2010-1431']['Freshmen']['Saudi']['Total'] ],
										[
												'Non-Saudi',
												model['Students']['2010-1431']['Freshmen']['Non-Saudi']['Total'] ] ],
								options : this.merge(this.defaultOptions(), {
									slices : {
										0 : {
											color : 'green'
										},
										1 : {
											color : 'darkGreen'
										}
									},
									title : 'Student nationality'
								})
							},
							'degreePie' : {
								data : [
										[ 'Degree', 'Students' ],
										[
												'Bachelore',
												model['Students']['2010-1431']['Freshmen']['Bachelore']['Total'] ],
										[
												'Diploma',
												model['Students']['2010-1431']['Freshmen']['Diploma']['Total'] ] ],
								options : this.merge(this.defaultOptions(), {
									slices : {
										0 : {
											color : 'brown'
										},
										1 : {
											color : 'DarkGoldenRod'
										}
									},
									title : 'Student degree'
								})
							},
							'saudiGenderPie' : {
								data : [
										[ 'Saudi student gender', 'Students' ],
										[
												'Male',
												model['Students']['2010-1431']['Freshmen']['Saudi']['Male'] ],
										[
												'Female',
												model['Students']['2010-1431']['Freshmen']['Saudi']['Female'] ] ],
								options : this.merge(this.defaultOptions(), {
									title : 'Saudi student gender'
								})
							},
							'nonSaudiGenderPie' : {
								data : [
										[ 'Non-Saudi student gender', 'Students' ],
										[
												'Male',
												model['Students']['2010-1431']['Freshmen']['Non-Saudi']['Male'] ],
										[
												'Female',
												model['Students']['2010-1431']['Freshmen']['Non-Saudi']['Female'] ] ],
								options : this.merge(this.defaultOptions(), {
									title : 'Non-Saudi student gender'
								})
							},
							'bacheloreGenderPie' : {
								data : [
										[ 'Bachelore student gender', 'Students' ],
										[
												'Male',
												model['Students']['2010-1431']['Freshmen']['Bachelore']['Male'] ],
										[
												'Female',
												model['Students']['2010-1431']['Freshmen']['Bachelore']['Female'] ] ],
								options : this.merge(this.defaultOptions(), {
									title : 'Bachelore student gender'
								})
							},
							'diplomaGenderPie' : {
								data : [
										[ 'Diploma student gender', 'Students' ],
										[
												'Male',
												model['Students']['2010-1431']['Freshmen']['Diploma']['Male'] ],
										[
												'Female',
												model['Students']['2010-1431']['Freshmen']['Diploma']['Female'] ] ],
								options : this.merge(this.defaultOptions(), {
									title : 'Diploma student gender'
								})
							},
						};
					};

					this.draw = function() {
						var chartData = this.createChartData(this.data);
						var chart1 = {};
						chart1.type = "PieChart";
						chart1.cssStyle = "height:200px; width:200px;";
						chart1.data = chartData[$scope.aspect].data;
						chart1.options = chartData[$scope.aspect].options;
						console.log(chart1);
						console.log($scope.selected);
						$scope.chart = chart1;
					}

					this.source = './json/2010-1431_students_freshmen_data.json';

					var self = this;
					$http.get(this.source).success(function(response) {
						self.data = response;
						console.log(self.data);
						
						self.draw();
					});

				});