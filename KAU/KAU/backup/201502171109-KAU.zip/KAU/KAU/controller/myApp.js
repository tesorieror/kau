/**
 * New node file
 */
var app = angular.module("myApp", [ "googlechart" ]);

app.controller("myAppCtrl", function() {
	console.log('App controller');
	
});